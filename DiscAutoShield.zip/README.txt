////
// Disc Auto Shield will automatically engage the shield pack when shooting the spinfusor. However, the true purpose of this script is to engage the shield
// pack when you perform discjump. This will ensure you use the least amount of energy / take the least amount of damage. There is obviously no way to differentiate 
// between shooting your disc into the air or performing a discjump, so the shield pack will just always engage.
//
// This is a modification of the original script "borShieldSki.vl2". The following items describe behavior.
//	- If you have a shield pack equipped, and you fire your spinfusor, and your shield pack *is not* currently enabled, 
//		then this script will auto-enable your shield pack for a brief moment so that you don't take damage (granting that you have enough energy available).
//		The shield will be automatically disabled after the DJ action.
//  - If you have a shield pack equipped, and you fire your spinfusor, and your shield pack *is* currently enabled, then no action will be taken. Your shield
//		pack will continue to be enabled without change.
//	- This script modified the borShieldSki.vl2 script as follows:
//		-- You could enable / disable the original script via keybind. We have enough keybinds. We don't need more. I have moved the configuration to a Script UI.
//         I suppose I can see an argument for wanting to quickly enable / disable it depending on the situation in game, but that seems quite unlikely.
//      -- The original script automatically turned on the script for *all* weapons. This script only enables it for the spinfusor.
//      -- In the original script, once the shield was turned on, it remained on until you manually turned it off. This in itself makes no sense. 
//         If you're performing a DJ, then you want to use as little energy as possible for that action. For example, if you turn on the shield to DJ, 
//         and then immediately jet after, but you do not turn off the shield, then you're wasting an enormous amount of energy.
////

-- Known "Issue" --
The script will always enable your shield if you fire your spinfusor. There are no other qualifications. This means that your shield will be enabled, even if you 
are currently reloading your spinfusor, or if you are out of ammo (dry fire). There is no way to prevent this. The T2 code does not expose the current "shoot" state
with a weapon, so it is what it is.


--Dependencies--
You must ensure you support the following dependencies:
1. HudManager.vl2
2. UberGuy's Script Suite. 
   (I am unsure what supports this. This must include: a) Scripts tab in the browser, b) UberPrefs support. Both of the these are included in the all-in-one download.)


--Instructions--
1. Move DiscAutoShield.vl2 to your z_scripts or scripts folder
	